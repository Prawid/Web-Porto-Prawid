// Toggle & Responsive Navigation
const navSlide = () => {
    const pengu = document.querySelector(".pengu");
    const navLists = document.querySelector("nav");
  
    pengu.addEventListener("click", () => {
      // Toggle nav list and pengu class
      navLists.classList.toggle("nav-active");
      pengu.classList.toggle("toggle-pengu");
    });
  };
  
  navSlide();
  
  // Clear form before unload
  window.onbeforeunload = () => {
    for (const form of document.getElementsByTagName("form")) {
      form.reset();
    }
  };
  